CONFIG FILE FROM @PEXIPEXCHAN


Steps to apply config file:
Copy the file named "files" into /storage/emulated/0/Android/data/your pubg folder/ then paste


Rules:
- Always monitor official telegram channel to prevent temporary ban of using config files.
- Must use firewall app every time you play.
- Must clear firewall app cache
- Always use latest block update file.
- Always monitor official telegram channel for latest firewall apk and firewall filters.